CREATE OR REPLACE FUNCTION private.default_staff_permissions()
 RETURNS jsonb
 LANGUAGE sql
 STABLE
 SET search_path TO ''
AS $function$
  select jsonb_build_object(
    'pos', true,
    'orders', true,
    'products', false,
    'customers', false,
    'reports', false,
    'settings', false,
    'devices', false,
    'license', false,
    'inventory', false,
    'cash_register', true,
    'discounts', false,
    'refunds', false,
    'ecommerce', false,
    'sync', false,
    'notifications', false,
    'notifications_ecommerce', true,
    'notifications_support', true,
    'notifications_license', true,
    'notifications_inventory', true,
    'notifications_operations', true,
    'notifications_system', true,
    'support_center', false,
    'ai_agents', false
  );
$function$
;
