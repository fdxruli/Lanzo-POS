# Shared Terminal repeated full-suite differential

- BASE repetition 1: 5612 passed / 75 failed / 52 skipped / 5739 total
- BASE repetition 2: 5612 passed / 75 failed / 52 skipped / 5739 total
- CANDIDATE repetition 1: 5637 passed / 75 failed / 52 skipped / 5764 total
- CANDIDATE repetition 2: 5637 passed / 75 failed / 52 skipped / 5764 total

- BASE focused regression repetition 1: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 2: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 3: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 4: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 5: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 6: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 7: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 8: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 9: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 10: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 11: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 12: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 13: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 14: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 15: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 16: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 17: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 18: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 19: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 20: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 21: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 22: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 23: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 24: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 25: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 26: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 27: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 28: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 29: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 30: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 31: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 32: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 33: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 34: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 35: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 36: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 37: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 38: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 39: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 40: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 41: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 42: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 43: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 44: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 45: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 46: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 47: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 48: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 49: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 50: 1 passed / 0 failed / 30 skipped / 31 total
- BASE focused regression repetition 51: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 52: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 53: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 54: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 55: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 56: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 57: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 58: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 59: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 60: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 61: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 62: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 63: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 64: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 65: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 66: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 67: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 68: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 69: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 70: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 71: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 72: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 73: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 74: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 75: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 76: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 77: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 78: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 79: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 80: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 81: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 82: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 83: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 84: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 85: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 86: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 87: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 88: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 89: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 90: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 91: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 92: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 93: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 94: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 95: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 96: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 97: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 98: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 99: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 100: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 101: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 102: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 103: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 104: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 105: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 106: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 107: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 108: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 109: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 110: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 111: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 112: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 113: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 114: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 115: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 116: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 117: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 118: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 119: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 120: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 121: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 122: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 123: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 124: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 125: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 126: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 127: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 128: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 129: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 130: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 131: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 132: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 133: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 134: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 135: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 136: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 137: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 138: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 139: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 140: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 141: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 142: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 143: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 144: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 145: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 146: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 147: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 148: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 149: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 150: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 151: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 152: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 153: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 154: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 155: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 156: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 157: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 158: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 159: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 160: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 161: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 162: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 163: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 164: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 165: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 166: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 167: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 168: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 169: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 170: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 171: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 172: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 173: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 174: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 175: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 176: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 177: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 178: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 179: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 180: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 181: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 182: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 183: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 184: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 185: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 186: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 187: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 188: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 189: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 190: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 191: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 192: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 193: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 194: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 195: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 196: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 197: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 198: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 199: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 200: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 201: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 202: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 203: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 204: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 205: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 206: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 207: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 208: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 209: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 210: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 211: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 212: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 213: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 214: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 215: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 216: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 217: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 218: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 219: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 220: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 221: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 222: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 223: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 224: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 225: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 226: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 227: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 228: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 229: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 230: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 231: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 232: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 233: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 234: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 235: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 236: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 237: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 238: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 239: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 240: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 241: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 242: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 243: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 244: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 245: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 246: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 247: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 248: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 249: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 250: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 251: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 252: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 253: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 254: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 255: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 256: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 257: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 258: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 259: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 260: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 261: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 262: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 263: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 264: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 265: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 266: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 267: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 268: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 269: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 270: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 271: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 272: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 273: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 274: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 275: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 276: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 277: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 278: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 279: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 280: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 281: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 282: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 283: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 284: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 285: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 286: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 287: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 288: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 289: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 290: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 291: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 292: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 293: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 294: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 295: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 296: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 297: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 298: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 299: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 300: 1 passed / 0 failed / 7 skipped / 8 total
- BASE focused regression repetition 301: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 302: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 303: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 304: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 305: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 306: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 307: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 308: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 309: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 310: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 311: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 312: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 313: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 314: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 315: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 316: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 317: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 318: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 319: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 320: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 321: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 322: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 323: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 324: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 325: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 326: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 327: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 328: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 329: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 330: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 331: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 332: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 333: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 334: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 335: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 336: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 337: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 338: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 339: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 340: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 341: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 342: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 343: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 344: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 345: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 346: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 347: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 348: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 349: 1 passed / 0 failed / 0 skipped / 1 total
- BASE focused regression repetition 350: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 1: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 2: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 3: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 4: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 5: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 6: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 7: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 8: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 9: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 10: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 11: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 12: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 13: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 14: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 15: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 16: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 17: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 18: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 19: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 20: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 21: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 22: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 23: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 24: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 25: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 26: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 27: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 28: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 29: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 30: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 31: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 32: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 33: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 34: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 35: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 36: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 37: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 38: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 39: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 40: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 41: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 42: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 43: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 44: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 45: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 46: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 47: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 48: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 49: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 50: 1 passed / 0 failed / 30 skipped / 31 total
- CANDIDATE focused regression repetition 51: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 52: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 53: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 54: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 55: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 56: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 57: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 58: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 59: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 60: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 61: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 62: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 63: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 64: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 65: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 66: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 67: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 68: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 69: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 70: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 71: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 72: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 73: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 74: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 75: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 76: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 77: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 78: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 79: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 80: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 81: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 82: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 83: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 84: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 85: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 86: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 87: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 88: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 89: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 90: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 91: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 92: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 93: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 94: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 95: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 96: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 97: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 98: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 99: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 100: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 101: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 102: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 103: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 104: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 105: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 106: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 107: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 108: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 109: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 110: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 111: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 112: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 113: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 114: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 115: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 116: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 117: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 118: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 119: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 120: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 121: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 122: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 123: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 124: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 125: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 126: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 127: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 128: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 129: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 130: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 131: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 132: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 133: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 134: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 135: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 136: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 137: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 138: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 139: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 140: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 141: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 142: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 143: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 144: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 145: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 146: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 147: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 148: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 149: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 150: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 151: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 152: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 153: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 154: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 155: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 156: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 157: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 158: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 159: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 160: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 161: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 162: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 163: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 164: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 165: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 166: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 167: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 168: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 169: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 170: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 171: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 172: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 173: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 174: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 175: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 176: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 177: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 178: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 179: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 180: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 181: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 182: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 183: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 184: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 185: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 186: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 187: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 188: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 189: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 190: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 191: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 192: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 193: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 194: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 195: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 196: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 197: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 198: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 199: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 200: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 201: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 202: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 203: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 204: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 205: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 206: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 207: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 208: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 209: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 210: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 211: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 212: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 213: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 214: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 215: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 216: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 217: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 218: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 219: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 220: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 221: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 222: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 223: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 224: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 225: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 226: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 227: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 228: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 229: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 230: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 231: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 232: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 233: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 234: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 235: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 236: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 237: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 238: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 239: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 240: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 241: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 242: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 243: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 244: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 245: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 246: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 247: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 248: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 249: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 250: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 251: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 252: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 253: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 254: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 255: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 256: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 257: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 258: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 259: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 260: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 261: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 262: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 263: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 264: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 265: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 266: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 267: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 268: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 269: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 270: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 271: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 272: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 273: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 274: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 275: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 276: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 277: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 278: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 279: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 280: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 281: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 282: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 283: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 284: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 285: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 286: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 287: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 288: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 289: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 290: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 291: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 292: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 293: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 294: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 295: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 296: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 297: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 298: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 299: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 300: 1 passed / 0 failed / 7 skipped / 8 total
- CANDIDATE focused regression repetition 301: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 302: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 303: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 304: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 305: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 306: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 307: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 308: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 309: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 310: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 311: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 312: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 313: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 314: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 315: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 316: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 317: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 318: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 319: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 320: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 321: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 322: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 323: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 324: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 325: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 326: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 327: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 328: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 329: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 330: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 331: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 332: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 333: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 334: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 335: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 336: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 337: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 338: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 339: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 340: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 341: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 342: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 343: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 344: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 345: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 346: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 347: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 348: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 349: 1 passed / 0 failed / 0 skipped / 1 total
- CANDIDATE focused regression repetition 350: 1 passed / 0 failed / 0 skipped / 1 total
- NEW/CHANGED REGRESSIONS: 0
- OPAQUE ONE-OFF FAILURES CLEARED BY FOCUSED EVIDENCE: 0
- STABLE PREEXISTING CANDIDATE FAILURES: 93
- PREEXISTING FLAKY CANDIDATE FAILURES: 0
- INCIDENTAL/BASELINE-FLAKE OBSERVATIONS: 0

## Candidate failure matrix

| Test / file | BASE repetitions | CANDIDATE repetitions | Classification |
|---|---|---|---|
| src/tests/useStoreSync.test.js > [file-level failure] | FAIL in repetition(s) 1,2: Cannot find package '@testing-library/react-hooks' imported from 'subject/src/tests/useStoreSync.test.js' | FAIL in repetition(s) 1,2: Cannot find package '@testing-library/react-hooks' imported from 'subject/src/tests/useStoreSync.test.js' | PREEXISTING_BASELINE_FAILURE |
| src/utils/storageManager.test.js > [file-level failure] | FAIL in repetition(s) 1,2: No test suite found in file subject/src/utils/storageManager.test.js | FAIL in repetition(s) 1,2: No test suite found in file subject/src/utils/storageManager.test.js | PREEXISTING_BASELINE_FAILURE |
| scripts/oss/release-boundary.test.mjs > [file-level failure] | FAIL in repetition(s) 1,2: No test suite found in file subject/scripts/oss/release-boundary.test.mjs | FAIL in repetition(s) 1,2: No test suite found in file subject/scripts/oss/release-boundary.test.mjs | PREEXISTING_BASELINE_FAILURE |
| src/architecture/__tests__/adminDeploymentPackage.test.js > [file-level failure] | FAIL in repetition(s) 1,2: {"status":"failed","error":"Target already exists: cp returned EEXIST (/tmp/lanzo-pos-cutover-1-1-<tmp> already exists) /tmp/lanzo-pos-cutover-1-1-<tmp>"} | FAIL in repetition(s) 1,2: {"status":"failed","error":"Target already exists: cp returned EEXIST (/tmp/lanzo-pos-cutover-1-1-<tmp> already exists) /tmp/lanzo-pos-cutover-1-1-<tmp>"} | PREEXISTING_BASELINE_FAILURE |
| src/architecture/__tests__/publicDeploymentArchitecture.test.js > [file-level failure] | FAIL in repetition(s) 1,2:  | FAIL in repetition(s) 1,2:  | PREEXISTING_BASELINE_FAILURE |
| src/hooks/__tests__/useNavigationGuard.test.jsx > useNavigationGuard bloquea la navegación aunque el formulario no haya cambiado | FAIL in repetition(s) 1,2: TypeError: Cannot read properties of undefined (reading 'Symbol(Node prepared with document state workarounds)') | FAIL in repetition(s) 1,2: TypeError: Cannot read properties of undefined (reading 'Symbol(Node prepared with document state workarounds)') | PREEXISTING_BASELINE_FAILURE |
| src/hooks/__tests__/useNavigationGuard.test.jsx > useNavigationGuard cancela la salida y conserva los datos capturados | FAIL in repetition(s) 1,2: TypeError: Cannot read properties of undefined (reading 'Symbol(Node prepared with document state workarounds)') | FAIL in repetition(s) 1,2: TypeError: Cannot read properties of undefined (reading 'Symbol(Node prepared with document state workarounds)') | PREEXISTING_BASELINE_FAILURE |
| src/hooks/__tests__/useNavigationGuard.test.jsx > useNavigationGuard descarta la operación y continúa al destino al confirmar | FAIL in repetition(s) 1,2: TypeError: Cannot read properties of undefined (reading 'Symbol(Node prepared with document state workarounds)') | FAIL in repetition(s) 1,2: TypeError: Cannot read properties of undefined (reading 'Symbol(Node prepared with document state workarounds)') | PREEXISTING_BASELINE_FAILURE |
| src/hooks/__tests__/useNavigationGuard.test.jsx > useNavigationGuard permite navegar sin advertencia después de guardar | FAIL in repetition(s) 1,2: TypeError: Cannot read properties of undefined (reading 'Symbol(Node prepared with document state workarounds)') | FAIL in repetition(s) 1,2: TypeError: Cannot read properties of undefined (reading 'Symbol(Node prepared with document state workarounds)') | PREEXISTING_BASELINE_FAILURE |
| src/hooks/__tests__/useNavigationGuard.test.jsx > useNavigationGuard activa la advertencia nativa del navegador mientras está habilitado | FAIL in repetition(s) 1,2: ReferenceError: document is not defined | FAIL in repetition(s) 1,2: ReferenceError: document is not defined | PREEXISTING_BASELINE_FAILURE |
| src/hooks/__tests__/useNavigationGuard.test.jsx > useNavigationGuard bloquea cambios de pestaña representados por parámetros de búsqueda | FAIL in repetition(s) 1,2: TypeError: Cannot read properties of undefined (reading 'Symbol(Node prepared with document state workarounds)') | FAIL in repetition(s) 1,2: TypeError: Cannot read properties of undefined (reading 'Symbol(Node prepared with document state workarounds)') | PREEXISTING_BASELINE_FAILURE |
| src/hooks/__tests__/useNavigationGuard.test.jsx > useNavigationGuard cierra el modal al confirmar salida hacia otra pestaña de la misma ruta | FAIL in repetition(s) 1,2: TypeError: Cannot read properties of undefined (reading 'Symbol(Node prepared with document state workarounds)') | FAIL in repetition(s) 1,2: TypeError: Cannot read properties of undefined (reading 'Symbol(Node prepared with document state workarounds)') | PREEXISTING_BASELINE_FAILURE |
| src/hooks/__tests__/useNavigationGuard.test.jsx > useNavigationGuard bloquea la navegación hacia atrás del historial | FAIL in repetition(s) 1,2: ReferenceError: document is not defined | FAIL in repetition(s) 1,2: ReferenceError: document is not defined | PREEXISTING_BASELINE_FAILURE |
| src/services/__test__/BackupRiskEvaluator.test.js > BackupRiskEvaluator debe calcular el riesgo L1 cuando pasa el umbral de 50 | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | PREEXISTING_BASELINE_FAILURE |
| src/services/__test__/BackupRiskEvaluator.test.js > BackupRiskEvaluator debe escalar al riesgo L3 cuando pasa de 300 | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | PREEXISTING_BASELINE_FAILURE |
| src/services/__test__/BackupRiskEvaluator.test.js > BackupRiskEvaluator no debe disparar alerta si el posponer esta activo | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | PREEXISTING_BASELINE_FAILURE |
| src/services/__test__/BackupRiskEvaluator.test.js > BackupRiskEvaluator debe reanudar la alerta L3 si se rebasa el limite de posponer | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | PREEXISTING_BASELINE_FAILURE |
| src/services/__test__/BackupRiskEvaluator.test.js > BackupRiskEvaluator debe marcar el respaldo como completado correctamente (Async) | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | PREEXISTING_BASELINE_FAILURE |
| src/services/__test__/BackupRiskEvaluator.test.js > BackupRiskEvaluator no debe lanzar ni registrar error cuando localStorage no existe | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | PREEXISTING_BASELINE_FAILURE |
| src/services/__test__/BackupRiskEvaluator.test.js > BackupRiskEvaluator startBackupRiskEvaluator no hace nada cuando localStorage no existe | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | PREEXISTING_BASELINE_FAILURE |
| src/services/__test__/BackupRiskEvaluator.test.js > BackupRiskEvaluator startBackupRiskEvaluator programa un solo ping inicial | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | PREEXISTING_BASELINE_FAILURE |
| src/services/__test__/cashOpeningPolicy.test.js > cashOpeningPolicy usa apertura manual como politica segura por defecto | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | PREEXISTING_BASELINE_FAILURE |
| src/services/__test__/cashOpeningPolicy.test.js > cashOpeningPolicy persiste la autoapertura solo cuando se configura explicitamente | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | PREEXISTING_BASELINE_FAILURE |
| src/services/__test__/cashOpeningPolicy.test.js > cashOpeningPolicy exige responsable y coincidencia entre fondo y conteo | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | PREEXISTING_BASELINE_FAILURE |
| src/services/__test__/cashOpeningPolicy.test.js > cashOpeningPolicy registra la diferencia contra el fondo sugerido | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | PREEXISTING_BASELINE_FAILURE |
| src/services/__test__/cashOpeningPolicy.test.js > cashOpeningPolicy identifica de forma explicita una apertura automatica | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | PREEXISTING_BASELINE_FAILURE |
| src/services/__test__/cashOpeningPolicyService.test.js > cashOpeningPolicy persiste la autoapertura solo cuando se configura explicitamente | FAIL in repetition(s) 1,2: AssertionError: expected 'manual' to be 'automatic' // Object.is equality | FAIL in repetition(s) 1,2: AssertionError: expected 'manual' to be 'automatic' // Object.is equality | PREEXISTING_BASELINE_FAILURE |
| src/services/orders/orderVersioning.test.js > orderVersioning compares revision before updatedAt or item count | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | PREEXISTING_BASELINE_FAILURE |
| src/services/orders/orderVersioning.test.js > orderVersioning uses updatedAt and then deviceId as deterministic tie breakers | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | PREEXISTING_BASELINE_FAILURE |
| src/services/orders/orderVersioning.test.js > orderVersioning reuses the main device id when available | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | FAIL in repetition(s) 1,2: ReferenceError: localStorage is not defined | PREEXISTING_BASELINE_FAILURE |
| src/store/__test__/useOrderStore.test.js > useOrderStore - mesas abiertas loadOpenOrder carga solo ventas con status open | FAIL in repetition(s) 1,2: AssertionError: expected { success: false, …(1) } to deeply equal { success: true } | FAIL in repetition(s) 1,2: AssertionError: expected { success: false, …(1) } to deeply equal { success: true } | PREEXISTING_BASELINE_FAILURE |
| src/store/__test__/useOrderStore.test.js > useOrderStore - mesas abiertas saveOrderAsOpen inserta nueva orden abierta y limpia la sesión | FAIL in repetition(s) 1,2: AssertionError: expected { success: false, …(1) } to deeply equal { success: true, …(1) } | FAIL in repetition(s) 1,2: AssertionError: expected { success: false, …(1) } to deeply equal { success: true, …(1) } | PREEXISTING_BASELINE_FAILURE |
| src/store/__test__/useOrderStore.test.js > useOrderStore - mesas abiertas saveOrderAsOpen actualiza orden activa liberando y re-reservando stock | FAIL in repetition(s) 1,2: AssertionError: expected { success: false, …(1) } to deeply equal { success: true, id: 'sale-open-2' } | FAIL in repetition(s) 1,2: AssertionError: expected { success: false, …(1) } to deeply equal { success: true, id: 'sale-open-2' } | PREEXISTING_BASELINE_FAILURE |
| src/store/__test__/useOrderStore.test.js > useOrderStore - mesas abiertas saveOrderAsOpen hace rollback best-effort si falla el upsert | FAIL in repetition(s) 1,2: AssertionError: expected 'El pedido está vacío.' to contain 'put failed' | FAIL in repetition(s) 1,2: AssertionError: expected 'El pedido está vacío.' to contain 'put failed' | PREEXISTING_BASELINE_FAILURE |
| src/store/__test__/useOrderStore.test.js > useOrderStore - mesas abiertas clearSession limpia order, activeOrderId y tableData | FAIL in repetition(s) 1,2: AssertionError: expected [ { id: 'prod', quantity: 1, …(1) } ] to deeply equal [] | FAIL in repetition(s) 1,2: AssertionError: expected [ { id: 'prod', quantity: 1, …(1) } ] to deeply equal [] | PREEXISTING_BASELINE_FAILURE |
| src/store/__test__/useStoreSync.test.js > Bidirectional Syncing: useOrderStore <-> useActiveOrders 1. debería enlazar correctamente ambos stores | FAIL in repetition(s) 1,2: TypeError: __vi_import_1__.useOrderStore.getState(...).linkWithActiveOrders is not a function | FAIL in repetition(s) 1,2: TypeError: __vi_import_1__.useOrderStore.getState(...).linkWithActiveOrders is not a function | PREEXISTING_BASELINE_FAILURE |
| src/store/__test__/useStoreSync.test.js > Bidirectional Syncing: useOrderStore <-> useActiveOrders 2. debería volcar datos a useOrderStore cuando se hace switchOrder | FAIL in repetition(s) 1,2: TypeError: __vi_import_1__.useOrderStore.getState(...).linkWithActiveOrders is not a function | FAIL in repetition(s) 1,2: TypeError: __vi_import_1__.useOrderStore.getState(...).linkWithActiveOrders is not a function | PREEXISTING_BASELINE_FAILURE |
| src/store/__test__/useStoreSync.test.js > Bidirectional Syncing: useOrderStore <-> useActiveOrders 3. debería actualizar useActiveOrders cuando useOrderStore es modificado | FAIL in repetition(s) 1,2: TypeError: __vi_import_1__.useOrderStore.getState(...).linkWithActiveOrders is not a function | FAIL in repetition(s) 1,2: TypeError: __vi_import_1__.useOrderStore.getState(...).linkWithActiveOrders is not a function | PREEXISTING_BASELINE_FAILURE |
| src/store/__test__/useStoreSync.test.js > Bidirectional Syncing: useOrderStore <-> useActiveOrders 4. el getter currentOrder en useOrderStore debe retornar la orden actual | FAIL in repetition(s) 1,2: TypeError: __vi_import_1__.useOrderStore.getState(...).linkWithActiveOrders is not a function | FAIL in repetition(s) 1,2: TypeError: __vi_import_1__.useOrderStore.getState(...).linkWithActiveOrders is not a function | PREEXISTING_BASELINE_FAILURE |
| src/utils/__tests__/dateUtils.test.js > [file-level failure] | FAIL in repetition(s) 1,2: describe is not defined | FAIL in repetition(s) 1,2: describe is not defined | PREEXISTING_BASELINE_FAILURE |
| src/utils/__tests__/ecommerceConfiguredProduct.test.js > ecommerceConfiguredProduct validates required, single, multiple, min and max groups | FAIL in repetition(s) 1,2: AssertionError: expected false to be true // Object.is equality | FAIL in repetition(s) 1,2: AssertionError: expected false to be true // Object.is equality | PREEXISTING_BASELINE_FAILURE |
| src/utils/__tests__/ecommerceConfiguredProduct.test.js > ecommerceConfiguredProduct builds a configured cart line and clamps quantity to exact variant stock | FAIL in repetition(s) 1,2: AssertionError: expected { success: false, valid: false, …(2) } to match object { success: true, …(4) }<br>(4 matching properties omitted from actual) | FAIL in repetition(s) 1,2: AssertionError: expected { success: false, valid: false, …(2) } to match object { success: true, …(4) }<br>(4 matching properties omitted from actual) | PREEXISTING_BASELINE_FAILURE |
| src/utils/__tests__/ecommerceConfiguredProduct.test.js > ecommerceConfiguredProduct creates a minimal server payload without client prices or names | FAIL in repetition(s) 1,2: AssertionError: expected { productId: '', quantity: 1 } to deeply equal { productId: 'product-1', …(3) } | FAIL in repetition(s) 1,2: AssertionError: expected { productId: '', quantity: 1 } to deeply equal { productId: 'product-1', …(3) } | PREEXISTING_BASELINE_FAILURE |
| index.test.ts > [file-level failure] | FAIL in repetition(s) 1,2: Deno is not defined | FAIL in repetition(s) 1,2: Deno is not defined | PREEXISTING_BASELINE_FAILURE |
| src/components/pos/__tests__/ProductCard.test.jsx > [file-level failure] | FAIL in repetition(s) 1,2: expect is not defined | FAIL in repetition(s) 1,2: expect is not defined | PREEXISTING_BASELINE_FAILURE |
| src/components/products/__tests__/ProductList.test.jsx > ProductList batch-backed grocery details uses sale units and the nearest active batch expiry on cards | FAIL in repetition(s) 1,2: TestingLibraryElementError: Unable to find an element with the text: /Caduca en \d+ días/. This could be because the text is broken up by multiple elements. In this case, you can provide a function for your text matcher to make your matcher more flexible.<br>Ignored nodes: comments, script, style<br><body><br>  <div><br>    <div<br>      class="product-list-container"<br>    ><br>      <div<br>        class="list-header"<br>      ><br>        <div<br>          class="title-group" | FAIL in repetition(s) 1,2: TestingLibraryElementError: Unable to find an element with the text: /Caduca en \d+ días/. This could be because the text is broken up by multiple elements. In this case, you can provide a function for your text matcher to make your matcher more flexible.<br>Ignored nodes: comments, script, style<br><body><br>  <div><br>    <div<br>      class="product-list-container"<br>    ><br>      <div<br>        class="list-header"<br>      ><br>        <div<br>          class="title-group" | PREEXISTING_BASELINE_FAILURE |
| src/components/settings/__tests__/OperationalSettings.cashOpening.test.jsx > OperationalSettings cash opening control disables automatic cash opening for cloud cash licenses | FAIL in repetition(s) 1,2: ReferenceError: document is not defined | FAIL in repetition(s) 1,2: ReferenceError: document is not defined | PREEXISTING_BASELINE_FAILURE |
| src/components/settings/__tests__/OperationalSettings.cashOpening.test.jsx > OperationalSettings cash opening control warns FREE/local users when automatic cash opening is enabled | FAIL in repetition(s) 1,2: ReferenceError: document is not defined | FAIL in repetition(s) 1,2: ReferenceError: document is not defined | PREEXISTING_BASELINE_FAILURE |
| src/hooks/pos/__tests__/useEcommercePosCheckoutSingleFlight.test.jsx > useEcommercePosCheckoutSingleFlight absorbs twenty rapid clicks, exposes starting and pins the ecommerce target | FAIL in repetition(s) 1,2: ReferenceError: document is not defined | FAIL in repetition(s) 1,2: ReferenceError: document is not defined | PREEXISTING_BASELINE_FAILURE |
| src/hooks/pos/__tests__/useEcommercePosCheckoutSingleFlight.test.jsx > useEcommercePosCheckoutSingleFlight keeps A as the expected target when selection changes to B before the deferred run | FAIL in repetition(s) 1,2: ReferenceError: document is not defined | FAIL in repetition(s) 1,2: ReferenceError: document is not defined | PREEXISTING_BASELINE_FAILURE |
| src/hooks/pos/__tests__/useEcommercePosCheckoutSingleFlight.test.jsx > useEcommercePosCheckoutSingleFlight resets only non-current A when target change aborts before lock acquisition | FAIL in repetition(s) 1,2: ReferenceError: document is not defined | FAIL in repetition(s) 1,2: ReferenceError: document is not defined | PREEXISTING_BASELINE_FAILURE |
| src/hooks/pos/__tests__/useEcommercePosCheckoutSingleFlight.test.jsx > useEcommercePosCheckoutSingleFlight ignores clicks silently while payment is already pending | FAIL in repetition(s) 1,2: ReferenceError: document is not defined | FAIL in repetition(s) 1,2: ReferenceError: document is not defined | PREEXISTING_BASELINE_FAILURE |
| src/hooks/pos/__tests__/useEcommercePosCheckoutSingleFlight.test.jsx > useEcommercePosCheckoutSingleFlight preserves the canonical contention path for a lock owned elsewhere | FAIL in repetition(s) 1,2: ReferenceError: document is not defined | FAIL in repetition(s) 1,2: ReferenceError: document is not defined | PREEXISTING_BASELINE_FAILURE |
| src/hooks/pos/__tests__/useEcommercePosCheckoutSingleFlight.test.jsx > useEcommercePosCheckoutSingleFlight clears stale starting and validating state and allows a real retry | FAIL in repetition(s) 1,2: ReferenceError: document is not defined | FAIL in repetition(s) 1,2: ReferenceError: document is not defined | PREEXISTING_BASELINE_FAILURE |
| src/hooks/pos/__tests__/useEcommercePosCheckoutSingleFlight.test.jsx > useEcommercePosCheckoutSingleFlight does not change normal POS checkout behavior or pass ecommerce arguments | FAIL in repetition(s) 1,2: ReferenceError: document is not defined | FAIL in repetition(s) 1,2: ReferenceError: document is not defined | PREEXISTING_BASELINE_FAILURE |
| src/hooks/pos/__tests__/usePosModals.mobileTransition.test.jsx > mobile POS history layer transitions hands the cart entry to payment without a second push or an unmarked duplicate | FAIL in repetition(s) 1,2: AssertionError: expected "pushState" to be called 1 times, but got 2 times | FAIL in repetition(s) 1,2: AssertionError: expected "pushState" to be called 1 times, but got 2 times | PREEXISTING_BASELINE_FAILURE |
| src/hooks/pos/__tests__/usePosModals.mobileTransition.test.jsx > mobile POS history layer transitions closes payment with the first Back and reaches the previous route with the second | FAIL in repetition(s) 1,2: AssertionError: expected 2 to be 1 // Object.is equality | FAIL in repetition(s) 1,2: AssertionError: expected 2 to be 1 // Object.is equality | PREEXISTING_BASELINE_FAILURE |
| src/hooks/pos/__tests__/usePosModals.mobileTransition.test.jsx > mobile POS history layer transitions does not accumulate invisible entries across three cart-payment-cancel cycles | FAIL in repetition(s) 1,2: AssertionError: expected 2 to be 1 // Object.is equality | FAIL in repetition(s) 1,2: AssertionError: expected 2 to be 1 // Object.is equality | PREEXISTING_BASELINE_FAILURE |
| src/hooks/pos/__tests__/usePosModals.mobileTransition.test.jsx > mobile POS history layer transitions reuses the cart entry for prescription and then payment | FAIL in repetition(s) 1,2: AssertionError: expected "pushState" to be called 1 times, but got 2 times | FAIL in repetition(s) 1,2: AssertionError: expected "pushState" to be called 1 times, but got 2 times | PREEXISTING_BASELINE_FAILURE |
| src/services/__test__/restaurant/restaurantOrderCheckoutClose.test.js > restaurantOrderCheckoutClose split bill support saves pending split close when offline | FAIL in repetition(s) 1,2: AssertionError: expected [] to have a length of 1 but got +0 | FAIL in repetition(s) 1,2: AssertionError: expected [] to have a length of 1 but got +0 | PREEXISTING_BASELINE_FAILURE |
| src/services/__test__/restaurant/restaurantOrderCheckoutClose.test.js > restaurantOrderCheckoutClose split bill support saves pending split close when repository returns failure | FAIL in repetition(s) 1,2: AssertionError: expected [] to have a length of 1 but got +0 | FAIL in repetition(s) 1,2: AssertionError: expected [] to have a length of 1 but got +0 | PREEXISTING_BASELINE_FAILURE |
| src/services/__test__/restaurant/restaurantOrderCheckoutClose.test.js > restaurantOrderCheckoutClose split bill support retries pending split close without losing paymentSummary | FAIL in repetition(s) 1,2: AssertionError: expected { success: true, closed: +0, …(2) } to match object { success: true, closed: 1, …(2) } | FAIL in repetition(s) 1,2: AssertionError: expected { success: true, closed: +0, …(2) } to match object { success: true, closed: 1, …(2) } | PREEXISTING_BASELINE_FAILURE |
| src/services/__test__/restaurant/restaurantOrderCheckoutClose.test.js > restaurantOrderCheckoutClose split bill support does not evict legacy rows when adding a new tenant-scoped retry | FAIL in repetition(s) 1,2: AssertionError: expected [ …(51) ] to have a length of 52 but got 51 | FAIL in repetition(s) 1,2: AssertionError: expected [ …(51) ] to have a length of 52 but got 51 | PREEXISTING_BASELINE_FAILURE |
| src/services/__test__/sales/financialStats.test.js > financialStats solo agrega ventas con status closed en daily stats | FAIL in repetition(s) 1,2: AssertionError: expected [ { id: '2026-03-12', …(14) } ] to deeply equal [ { id: '2026-03-12', …(7) } ] | FAIL in repetition(s) 1,2: AssertionError: expected [ { id: '2026-03-12', …(14) } ] to deeply equal [ { id: '2026-03-12', …(7) } ] | PREEXISTING_BASELINE_FAILURE |
| src/services/__test__/sales/inventoryFlow.test.js > inventoryFlow committed stock reserva lotes y sincroniza committedStock del padre | FAIL in repetition(s) 1,2: AssertionError: expected [ { batchId: 'b-1', …(5) } ] to deeply equal [ { batchId: 'b-1', …(3) } ] | FAIL in repetition(s) 1,2: AssertionError: expected [ { batchId: 'b-1', …(5) } ] to deeply equal [ { batchId: 'b-1', …(3) } ] | PREEXISTING_BASELINE_FAILURE |
| src/services/backup/__tests__/backupConfigDb.test.js > backupConfigDb persisted CryptoKey guarda y recupera una clave AES-GCM no extraible | FAIL in repetition(s) 1,2: MissingAPIError IndexedDB API missing. Please visit https://tinyurl.com/y2uuvskb<br>MissingAPIError IndexedDB API missing. Please visit https://tinyurl.com/y2uuvskb | FAIL in repetition(s) 1,2: MissingAPIError IndexedDB API missing. Please visit https://tinyurl.com/y2uuvskb<br>MissingAPIError IndexedDB API missing. Please visit https://tinyurl.com/y2uuvskb | PREEXISTING_BASELINE_FAILURE |
| src/services/backup/__tests__/backupRestore.test.js > restoreWhitelistedDatabase revierte los clear si una insercion falla dentro de la transaccion | FAIL in repetition(s) 1,2: AssertionError: expected [] to deeply equal [ { id: 'product-local' } ] | FAIL in repetition(s) 1,2: AssertionError: expected [] to deeply equal [ { id: 'product-local' } ] | PREEXISTING_BASELINE_FAILURE |
| src/services/ecommerce/__tests__/ecommerceCatalogApparelRevision.test.js > [file-level failure] | FAIL in repetition(s) 1,2: (0 , __vite_ssr_import_1__.createEcommercePublishedStockAlertService) is not a function | FAIL in repetition(s) 1,2: (0 , __vite_ssr_import_1__.createEcommercePublishedStockAlertService) is not a function | PREEXISTING_BASELINE_FAILURE |
| src/services/ecommerce/__tests__/ecommerceCatalogSyncConsistency.test.js > [file-level failure] | FAIL in repetition(s) 1,2: (0 , __vite_ssr_import_1__.createEcommercePublishedStockAlertService) is not a function | FAIL in repetition(s) 1,2: (0 , __vite_ssr_import_1__.createEcommercePublishedStockAlertService) is not a function | PREEXISTING_BASELINE_FAILURE |
| src/services/ecommerce/__tests__/ecommerceCatalogSyncFinalPayloadIdempotency.test.js > [file-level failure] | FAIL in repetition(s) 1,2: (0 , __vite_ssr_import_1__.createEcommercePublishedStockAlertService) is not a function | FAIL in repetition(s) 1,2: (0 , __vite_ssr_import_1__.createEcommercePublishedStockAlertService) is not a function | PREEXISTING_BASELINE_FAILURE |
| src/services/ecommerce/__tests__/ecommerceCatalogSyncRecipeDependencies.test.js > [file-level failure] | FAIL in repetition(s) 1,2: (0 , __vite_ssr_import_1__.createEcommercePublishedStockAlertService) is not a function | FAIL in repetition(s) 1,2: (0 , __vite_ssr_import_1__.createEcommercePublishedStockAlertService) is not a function | PREEXISTING_BASELINE_FAILURE |
| src/services/ecommerce/__tests__/ecommerceCatalogSyncService.retryOutbox.test.js > [file-level failure] | FAIL in repetition(s) 1,2: (0 , __vite_ssr_import_1__.createEcommercePublishedStockAlertService) is not a function | FAIL in repetition(s) 1,2: (0 , __vite_ssr_import_1__.createEcommercePublishedStockAlertService) is not a function | PREEXISTING_BASELINE_FAILURE |
| src/services/ecommerce/__tests__/ecommerceCatalogSyncService.test.js > [file-level failure] | FAIL in repetition(s) 1,2: (0 , __vite_ssr_import_1__.createEcommercePublishedStockAlertService) is not a function | FAIL in repetition(s) 1,2: (0 , __vite_ssr_import_1__.createEcommercePublishedStockAlertService) is not a function | PREEXISTING_BASELINE_FAILURE |
| src/services/ecommerce/__tests__/ecommercePosDraftService.test.js > ecommercePosDraftService maps the server-resolved sourceProductId while excluding customer PII from the draft | FAIL in repetition(s) 1,2: AssertionError: expected { id: 'product-1', …(19) } to match object { id: 'product-1', …(7) }<br>(13 matching properties omitted from actual) | FAIL in repetition(s) 1,2: AssertionError: expected { id: 'product-1', …(19) } to match object { id: 'product-1', …(7) }<br>(13 matching properties omitted from actual) | PREEXISTING_BASELINE_FAILURE |
| src/services/ecommerce/__tests__/ecommercePosDraftService.test.js > ecommercePosDraftService opens an existing local draft only when remote prepared identity matches completely | FAIL in repetition(s) 1,2: AssertionError: expected { success: true, created: true, …(2) } to match object { success: true, created: false, …(1) }<br>(17 matching properties omitted from actual) | FAIL in repetition(s) 1,2: AssertionError: expected { success: true, created: true, …(2) } to match object { success: true, created: false, …(1) }<br>(17 matching properties omitted from actual) | PREEXISTING_BASELINE_FAILURE |
| src/services/ecommerce/__tests__/ecommercePosInventoryResolution.test.js > stale response protection does not replace a manual selection with an older automatic response | FAIL in repetition(s) 1,2: AssertionError: expected false to be true // Object.is equality | FAIL in repetition(s) 1,2: AssertionError: expected false to be true // Object.is equality | PREEXISTING_BASELINE_FAILURE |
| src/services/ecommerce/__tests__/ecommercePosInventoryResolution.test.js > stale response protection does not recreate a released draft after a delayed response | FAIL in repetition(s) 1,2: AssertionError: expected 'ECOMMERCE_INVENTORY_DRAFT_INVALID' to be 'ECOMMERCE_INVENTORY_STALE_RESPONSE' // Object.is equality | FAIL in repetition(s) 1,2: AssertionError: expected 'ECOMMERCE_INVENTORY_DRAFT_INVALID' to be 'ECOMMERCE_INVENTORY_STALE_RESPONSE' // Object.is equality | PREEXISTING_BASELINE_FAILURE |
| src/services/ecommerce/__tests__/ecommercePublicConfiguredService.test.js > ecommercePublicService configurable products loads and normalizes the safe product configuration RPC | FAIL in repetition(s) 1,2: EcommercePublicError: La configuración cambió. Actualiza el catálogo. | FAIL in repetition(s) 1,2: EcommercePublicError: La configuración cambió. Actualiza el catálogo. | PREEXISTING_BASELINE_FAILURE |
| src/services/ecommerce/__tests__/ecommercePublicConfiguredService.test.js > ecommercePublicService configurable products sends only productId, quantity, variantId and canonical selections | FAIL in repetition(s) 1,2: AssertionError: expected "vi.fn()" to be called with arguments: [ 'ecommerce_create_order', …(1) ]<br>Received:<br>  1st vi.fn() call:<br>@@ -1,10 +1,20 @@<br>  [<br>    "ecommerce_create_order",<br>-   ObjectContaining {<br>+   {<br>+     "p_customer": {<br>+       "address": "",<br>+       "fulfillmentMethod": "pickup",<br>+       "name": "Cliente", | FAIL in repetition(s) 1,2: AssertionError: expected "vi.fn()" to be called with arguments: [ 'ecommerce_create_order', …(1) ]<br>Received:<br>  1st vi.fn() call:<br>@@ -1,10 +1,20 @@<br>  [<br>    "ecommerce_create_order",<br>-   ObjectContaining {<br>+   {<br>+     "p_customer": {<br>+       "address": "",<br>+       "fulfillmentMethod": "pickup",<br>+       "name": "Cliente", | PREEXISTING_BASELINE_FAILURE |
| src/services/ecommerce/__tests__/ecommercePublicService.test.js > ecommercePublicService maps ECOMMERCE_CATALOG_REVISION_CHANGED to a controlled checkout message | FAIL in repetition(s) 1,2: AssertionError: expected EcommercePublicError: No pudimos confirma… { …(6) } to match object { …(2) }<br>(9 matching properties omitted from actual) | FAIL in repetition(s) 1,2: AssertionError: expected EcommercePublicError: No pudimos confirma… { …(6) } to match object { …(2) }<br>(9 matching properties omitted from actual) | PREEXISTING_BASELINE_FAILURE |
| src/services/ecommerce/__tests__/ecommercePublicService.test.js > ecommercePublicService maps ECOMMERCE_PRODUCT_NOT_AVAILABLE to a controlled checkout message | FAIL in repetition(s) 1,2: AssertionError: expected EcommercePublicError: Este producto ya no… { …(6) } to match object { …(2) }<br>(9 matching properties omitted from actual) | FAIL in repetition(s) 1,2: AssertionError: expected EcommercePublicError: Este producto ya no… { …(6) } to match object { …(2) }<br>(9 matching properties omitted from actual) | PREEXISTING_BASELINE_FAILURE |
| src/services/ecommerce/__tests__/ecommercePublicService.test.js > ecommercePublicService maps ECOMMERCE_ORDER_CREATE_FAILED to a controlled checkout message | FAIL in repetition(s) 1,2: AssertionError: expected EcommercePublicError: No pudimos procesar… { …(5) } to match object { …(2) }<br>(8 matching properties omitted from actual) | FAIL in repetition(s) 1,2: AssertionError: expected EcommercePublicError: No pudimos procesar… { …(5) } to match object { …(2) }<br>(8 matching properties omitted from actual) | PREEXISTING_BASELINE_FAILURE |
| src/services/ecommerce/__tests__/ecommercePublicTrackingContract.test.js > checkout tracking contract keeps the same tracking link on an idempotent response | FAIL in repetition(s) 1,2: AssertionError: expected { success: true, …(3) } to match object { idempotent: true, order: { …(3) } }<br>(12 matching properties omitted from actual) | FAIL in repetition(s) 1,2: AssertionError: expected { success: true, …(3) } to match object { idempotent: true, order: { …(3) } }<br>(12 matching properties omitted from actual) | PREEXISTING_BASELINE_FAILURE |
| src/services/ecommerce/__tests__/ecommercePublishedStockAlertInvalidation.test.js > [file-level failure] | FAIL in repetition(s) 1,2: (0 , __vite_ssr_import_1__.createEcommercePublishedStockAlertService) is not a function | FAIL in repetition(s) 1,2: (0 , __vite_ssr_import_1__.createEcommercePublishedStockAlertService) is not a function | PREEXISTING_BASELINE_FAILURE |
| src/services/ecommerce/__tests__/ecommercePublishedStockAlertRecipe.test.js > [file-level failure] | FAIL in repetition(s) 1,2: (0 , __vite_ssr_import_1__.createEcommercePublishedStockAlertService) is not a function | FAIL in repetition(s) 1,2: (0 , __vite_ssr_import_1__.createEcommercePublishedStockAlertService) is not a function | PREEXISTING_BASELINE_FAILURE |
| src/services/ecommerce/__tests__/ecommercePublishedStockAlertService.test.js > [file-level failure] | FAIL in repetition(s) 1,2: (0 , __vite_ssr_import_1__.createEcommercePublishedStockAlertService) is not a function | FAIL in repetition(s) 1,2: (0 , __vite_ssr_import_1__.createEcommercePublishedStockAlertService) is not a function | PREEXISTING_BASELINE_FAILURE |
| src/services/ecommerce/__tests__/ecommercePublishedStockMalformedBatch.test.js > [file-level failure] | FAIL in repetition(s) 1,2: (0 , __vite_ssr_import_1__.createEcommercePublishedStockAlertService) is not a function | FAIL in repetition(s) 1,2: (0 , __vite_ssr_import_1__.createEcommercePublishedStockAlertService) is not a function | PREEXISTING_BASELINE_FAILURE |
| src/services/sales/__tests__/receiptWhatsApp.ecommerce.test.js > receiptWhatsApp money formatting and ecommerce traceability formats exact-string prices and totals while preserving ecommerce references | FAIL in repetition(s) 1,2: AssertionError: expected "vi.fn()" to be called 1 times, but got 0 times | FAIL in repetition(s) 1,2: AssertionError: expected "vi.fn()" to be called 1 times, but got 0 times | PREEXISTING_BASELINE_FAILURE |
| src/services/sales/__tests__/receiptWhatsApp.ecommerce.test.js > receiptWhatsApp money formatting and ecommerce traceability shows subtotal, discount detail, final total, received cash and change | FAIL in repetition(s) 1,2: TypeError: undefined is not iterable (cannot read property Symbol(Symbol.iterator)) | FAIL in repetition(s) 1,2: TypeError: undefined is not iterable (cannot read property Symbol(Symbol.iterator)) | PREEXISTING_BASELINE_FAILURE |
| src/services/sales/__tests__/receiptWhatsApp.ecommerce.test.js > receiptWhatsApp money formatting and ecommerce traceability reads aggregate discount data from metadata when needed | FAIL in repetition(s) 1,2: TypeError: undefined is not iterable (cannot read property Symbol(Symbol.iterator)) | FAIL in repetition(s) 1,2: TypeError: undefined is not iterable (cannot read property Symbol(Symbol.iterator)) | PREEXISTING_BASELINE_FAILURE |
| src/services/sales/__tests__/receiptWhatsApp.ecommerce.test.js > receiptWhatsApp money formatting and ecommerce traceability calculates cash change from exact-string monetary values | FAIL in repetition(s) 1,2: TypeError: undefined is not iterable (cannot read property Symbol(Symbol.iterator)) | FAIL in repetition(s) 1,2: TypeError: undefined is not iterable (cannot read property Symbol(Symbol.iterator)) | PREEXISTING_BASELINE_FAILURE |
| src/services/sales/__tests__/receiptWhatsApp.ecommerce.test.js > receiptWhatsApp money formatting and ecommerce traceability formats credit payment and pending balance from exact strings | FAIL in repetition(s) 1,2: TypeError: undefined is not iterable (cannot read property Symbol(Symbol.iterator)) | FAIL in repetition(s) 1,2: TypeError: undefined is not iterable (cannot read property Symbol(Symbol.iterator)) | PREEXISTING_BASELINE_FAILURE |
| src/services/sales/__tests__/receiptWhatsApp.ecommerce.test.js > receiptWhatsApp money formatting and ecommerce traceability preserves pharmacy receipt details and metadata-only ecommerce references | FAIL in repetition(s) 1,2: TypeError: undefined is not iterable (cannot read property Symbol(Symbol.iterator)) | FAIL in repetition(s) 1,2: TypeError: undefined is not iterable (cannot read property Symbol(Symbol.iterator)) | PREEXISTING_BASELINE_FAILURE |

## BASE failure observations absent from all candidate repetitions

- None
