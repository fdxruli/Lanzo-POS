# Focused target differential

| Target | File | BASE pass/fail/not-executed/unreadable | CANDIDATE pass/fail/not-executed/unreadable | Candidate-only semantics (repeated / observed) | Failure-rate p-value |
|---|---|---|---|---|---|
| bfcache | src/pages/__tests__/PublicStorePage.test.jsx | 50/0/0/0 | 50/0/0/0 | 0 / 0 | 1.0000 |
| site-version | src/pages/__tests__/PublicStorePage.siteVersion.test.jsx | 50/0/0/0 | 50/0/0/0 | 0 / 0 | 1.0000 |
| ecommerce-latest-search-cursor | src/components/ecommerce/__tests__/EcommercePortalSettings.productModalLifecycle.test.jsx | 50/0/0/0 | 50/0/0/0 | 0 / 0 | 1.0000 |
| ecommerce-same-search-next-page | src/components/ecommerce/__tests__/EcommercePortalSettings.productModalLifecycle.test.jsx | 50/0/0/0 | 50/0/0/0 | 0 / 0 | 1.0000 |
| ecommerce-clear-search-restore-catalog | src/components/ecommerce/__tests__/EcommercePortalSettings.productModalLifecycle.test.jsx | 50/0/0/0 | 50/0/0/0 | 0 / 0 | 1.0000 |
| ecommerce-stale-search-response | src/components/ecommerce/__tests__/EcommercePortalSettings.productModalLifecycle.test.jsx | 50/0/0/0 | 50/0/0/0 | 0 / 0 | 1.0000 |
| ecommerce-stale-load-more-loading | src/components/ecommerce/__tests__/EcommercePortalSettings.productModalLifecycle.test.jsx | 50/0/0/0 | 50/0/0/0 | 0 / 0 | 1.0000 |

- FOCUSED_TARGET_NOT_EXECUTED: 0
- EVIDENCE_UNREADABLE: 0
- SEMANTIC_IDENTITY_UNRESOLVED: 0
- CANDIDATE-ONLY SEMANTIC REGRESSIONS (same error in 2+ independent runs): 0
- SINGLE-RUN CANDIDATE-ONLY SEMANTIC OBSERVATIONS: 0
- CANDIDATE FAILURE-RATE REGRESSIONS: 0
